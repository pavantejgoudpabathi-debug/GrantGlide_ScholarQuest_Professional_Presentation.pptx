# GrantGlide: ScholarQuest

GrantGlide is a scholarship matching and readiness demo for college students in India. It combines a browser interface, a REST API, scholarship eligibility rules, document-readiness checks, a conflict-aware aid planner, and a WhatsApp alert message simulator.

## Run in VS Code

1. Extract the ZIP.
2. Open the inner grantglide-scholarquest folder in VS Code. It is the folder containing README.md, backend, and frontend.
3. Open Terminal → New Terminal.

If the terminal is already at the project root, run:

~~~powershell
cd backend
npm.cmd install
npm.cmd test
npm.cmd start
~~~

If the terminal is at the outer extraction folder, first enter the project and backend folders:

~~~powershell
cd .\grantglide-scholarquest\backend
npm.cmd install
npm.cmd test
npm.cmd start
~~~

Run each command separately. npm.cmd works around PowerShell configurations that block the npm.ps1 script. Open http://localhost:3000 after the server reports that it is running. Keep the terminal open while using the app.

Use Node.js 20 or newer.

## Technical implementation

### Runtime and application structure

- The browser client is plain HTML, CSS, and JavaScript. It has no bundler or frontend package install.
- Express 5 serves the static files from frontend/ and exposes the API under /api.
- The backend uses JSON files for the scholarship catalog, document catalog, and local demo student store.
- server.js exports createApp() so the HTTP app can be exercised on an ephemeral port by automated tests.

### Scholarship matching flow

1. The client sends the profile, selected category, search query, and selected scholarship IDs to POST /api/match.
2. Zod validates and coerces supported profile fields. The server saves the profile in the local demo store.
3. matchingEngine.js evaluates each scholarship's ruleTree recursively. Supported leaf operators are eq, lte, gte, and in; rule trees combine leaves with and and or.
4. The response includes eligibility, field-level traces, deadline countdowns, document readiness, near-miss results, and an aid plan.
5. A match score is calculated from the share of traced rule leaves that pass. Scholarships below eligibility with a score of at least 60% are returned as near misses. This score is a diagnostic aid, not a probability of receiving an award.
6. The response includes an HMAC-SHA256 signature over the student ID, eligible scholarship IDs, and recommended aid total.

A scholarship rule can be represented as JSON like this:

~~~json
{
  "and": [
    { "field": "gpa", "op": "gte", "value": 7.5 },
    {
      "or": [
        { "field": "caste", "op": "in", "value": ["SC", "ST"] },
        { "field": "singleGirlChild", "op": "eq", "value": true }
      ]
    }
  ]
}
~~~

### Document and aid calculations

- The document readiness engine reads each scheme's required document IDs and the canonical document catalog. It uses each document's validity period to report valid, expiring, expired, or missing status; the expiry warning window is 30 days.
- Document issue dates must be valid calendar dates, not just strings with a YYYY-MM-DD shape.
- The aid planner detects exclusions declared by either scheme and schemes that share a conflictGroup. It builds a symmetric conflict graph, sorts awards by amount, and greedily constructs a conflict-free stack. This is a heuristic and may not produce the mathematically highest-value stack for every possible conflict graph.
- Tuition coverage is capped at 100%. The planner also returns selected aid, total recommended aid, and remaining tuition deficit.
- Deadline labels use days, hours, and minutes remaining. Urgency is marked critical at 7 days or fewer, urgent at 14 days or fewer, and moderate at 25 days or fewer.

### API routes

| Method and route | Purpose |
| --- | --- |
| GET /api/health | Service status and loaded catalog count |
| GET /api/scholarships | Catalog listing with optional category and search filters |
| GET /api/student/:studentId | Read a local student profile, documents, and applications |
| POST /api/match | Validate a profile and calculate eligibility and aid results |
| POST /api/documents/toggle | Update a demo document's readiness and issue date |
| POST /api/applications/stage | Save a demo scholarship application stage |
| POST /api/alerts/whatsapp | Build a WhatsApp-style alert message; it does not send or schedule a real message |

### Security controls and limits

- Helmet sets browser security headers and a Content Security Policy. The server disables the X-Powered-By header.
- CORS allows same-origin requests and localhost development origins.
- API requests are rate limited; profile, document, and application mutations have a stricter limit.
- JSON request bodies are limited to 64 KB. A sanitizer removes dangerous object keys and control characters before schema validation.
- Zod schemas validate profile, document, and application-stage inputs.
- Development creates a random HMAC key for each server process. Production mode requires GRANTGLIDE_HMAC_SECRET with at least 32 characters.
- HMAC signatures provide payload integrity checks. They do not authenticate users or prove that a scholarship authority approved an eligibility decision.

The app stores the demo profile in backend/data/student_store.json. This file is local, unencrypted JSON. The demo has no login or per-student access control. Use synthetic data only; do not enter real student records or documents. A real deployment needs authentication, authorization, protected database storage, and a reviewed retention policy.

To generate a production signing secret:

~~~powershell
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
~~~

Set the generated value in the same PowerShell window before starting the server:

~~~powershell
$env:GRANTGLIDE_HMAC_SECRET = "paste-the-generated-value-here"
$env:NODE_ENV = "production"
npm.cmd start
~~~

### Tests and dependency checks

Run the project's built-in Node test suite and dependency audit from backend/:

~~~powershell
npm.cmd test
npm.cmd audit
~~~

Tests cover nested eligibility rules, deadlines, document expiry, one-sided conflict declarations, validation, signing-secret requirements, the health endpoint, and static frontend delivery.

## Project structure

- frontend/ — page, responsive styles, and browser interactions
- backend/server.js — Express application and static-file hosting
- backend/routes/ — API endpoints and demo store handling
- backend/services/matchingEngine.js — rules, deadlines, documents, and aid planning
- backend/middleware/security.js — headers, rate limits, input sanitization, schemas, and HMAC signing
- backend/data/ — scholarship and document catalogs; the local student store is created on first run
- backend/test/ — automated unit and HTTP integration tests
