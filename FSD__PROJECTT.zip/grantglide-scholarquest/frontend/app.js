(() => {
  const STUDENT_ID = 'demo-student-01';
  const state = {
    category: 'All',
    search: '',
    lastMatchData: null,
    selectedIds: [],
    matchRequestId: 0
  };

  const $ = (id) => document.getElementById(id);

  function formatINR(amount) {
    return '₹' + Number(amount || 0).toLocaleString('en-IN');
  }

  function escapeText(str) {
    const div = document.createElement('div');
    div.textContent = String(str ?? '');
    return div.textContent;
  }

  function readFormProfile() {
    return {
      studentId: STUDENT_ID,
      name: $('studentName').value.trim() || 'Ananya Rao',
      gender: $('gender').value,
      caste: $('caste').value,
      state: $('state').value,
      annualIncome: Number($('annualIncome').value || 0),
      gpa: Number($('gpa').value || 0),
      degree: $('degree').value,
      tuitionFee: Number($('tuitionFee').value || 0),
      singleGirlChild: $('singleGirlChild').checked,
      disability: $('disability').checked,
      language: $('langSelect').value
    };
  }

  async function refreshMatch() {
    const requestId = ++state.matchRequestId;
    const appStatus = $('appStatus');
    appStatus.dataset.state = 'loading';
    appStatus.textContent = 'Updating scholarship matches…';

    try {
      const profile = readFormProfile();
      const res = await fetch('/api/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...profile,
          category: state.category,
          search: state.search,
          selectedIds: state.selectedIds
        })
      });
      if (!res.ok) {
        throw new Error('Match request failed with status ' + res.status);
      }

      const data = await res.json();
      if (requestId !== state.matchRequestId) return;
      state.lastMatchData = data;
      renderAll(data);
      appStatus.dataset.state = 'ready';
      appStatus.textContent = 'Updated. ' + data.eligibleCount + ' scholarships currently match.';
    } catch (error) {
      console.error('Match error:', error);
      if (requestId !== state.matchRequestId) return;
      appStatus.dataset.state = 'error';
      appStatus.textContent = 'Could not load scholarship matches. Check the server connection and try again.';
    }
  }
  function renderAll(data) {
    const { eligible, nearMiss, aidPlan, documents, docCatalog, applications, totalCatalogCount, eligibleCount, nearMissCount, attestation } = data;

    // KPIs
    $('kpiEligibleCount').textContent = String(eligibleCount);
    $('kpiCatalogMeta').textContent = `of ${totalCatalogCount} schemes evaluated`;
    $('kpiOptimalAid').textContent = formatINR(aidPlan.optimalTotalAid);
    $('kpiDeficitMeta').textContent = `Deficit: ${formatINR(aidPlan.remainingDeficitAfterOptimal)}`;
    $('kpiNearMissCount').textContent = String(nearMissCount);

    // Doc readiness & expiry summary
    const docEntries = Object.values(documents || {});
    const readyDocs = docEntries.filter((d) => d.ready).length;
    const totalDocs = Object.keys(docCatalog || {}).length || 1;
    const overallPct = Math.round((readyDocs / totalDocs) * 100);
    $('kpiDocReadiness').textContent = `${overallPct}%`;

    const expiringCount = eligible.reduce((acc, s) => acc + (s.docReadiness?.expiringSoonCount || 0), 0);
    $('kpiExpiryAlert').textContent = `${expiringCount} expiring/issue ≤ 30d`;
    $('kpiExpiryAlert').className = `kpi-meta ${expiringCount > 0 ? 'accent-amber' : ''}`;

    // Aid & Conflict Panel
    $('aidCoverageBadge').textContent = `${aidPlan.coveragePct}% Covered`;
    $('aidTuitionVal').textContent = formatINR(aidPlan.tuitionFee);
    $('aidOptimalVal').textContent = formatINR(aidPlan.optimalTotalAid);
    $('aidDeficitVal').textContent = formatINR(aidPlan.remainingDeficitAfterOptimal);

    const conflictBanner = $('conflictBanner');
    if (aidPlan.conflicts && aidPlan.conflicts.length > 0) {
      conflictBanner.classList.remove('hidden');
      conflictBanner.innerHTML = aidPlan.conflicts
        .map(
          (c) =>
            `<strong>Policy Conflict:</strong> ${escapeText(c.schemeA.name)} ↔ ${escapeText(c.schemeB.name)} (${escapeText(c.reason)})`
        )
        .join('<br/>');
    } else {
      conflictBanner.classList.add('hidden');
      conflictBanner.textContent = '';
    }

    const stackList = $('optimalStackList');
    stackList.innerHTML = '';
    if (!aidPlan.optimalStack || aidPlan.optimalStack.length === 0) {
      stackList.innerHTML = '<li class="muted-sm">No non-conflicting awards matched for current criteria.</li>';
    } else {
      aidPlan.optimalStack.slice(0, 5).forEach((item) => {
        const li = document.createElement('li');
        li.className = 'stack-item';
        li.innerHTML = `<span>${escapeText(item.name)}</span><strong>${formatINR(item.amount)}</strong>`;
        stackList.appendChild(li);
      });
    }

    // Document Vault
    renderDocVault(docCatalog, documents, $('state').value);

    // Scholarship Cards
    renderScholarshipFeed(eligible, applications);

    // Near Miss Cards
    renderNearMiss(nearMiss);

    // Pipeline Tracker
    renderPipeline(eligible, applications);

    // Attestation
    if (attestation?.signature) {
      $('hmacSignature').textContent = `${attestation.algorithm}: ${attestation.signature.slice(0, 24)}...`;
    }
  }

  function renderDocVault(docCatalog, documents, userState) {
    const container = $('docVaultList');
    container.innerHTML = '';
    Object.values(docCatalog || {}).forEach((doc) => {
      const userDoc = (documents && documents[doc.canonicalId]) || { ready: false, issuedDate: null };
      const aliasText = doc.aliases?.[userState] || doc.aliases?.Default || doc.canonicalName;

      let alertHtml = '';
      if (userDoc.ready && userDoc.issuedDate) {
        const issuedMs = new Date(userDoc.issuedDate).getTime();
        const expiresMs = issuedMs + (doc.validityDays || 365) * 24 * 60 * 60 * 1000;
        const daysLeft = Math.ceil((expiresMs - Date.now()) / (1000 * 60 * 60 * 24));
        if (daysLeft <= 0) {
          alertHtml = `<div class="doc-expiry-crit">Expired (${Math.abs(daysLeft)}d ago) — Renewal required</div>`;
        } else if (daysLeft <= 30) {
          alertHtml = `<div class="doc-expiry-warn">Expiring in ${daysLeft} days — Renew soon</div>`;
        }
      }

      const row = document.createElement('div');
      row.className = 'doc-row';
      row.innerHTML = `
        <div>
          <div class="doc-name">${escapeText(doc.canonicalName)}</div>
          <div class="doc-alias">State alias: ${escapeText(aliasText)}</div>
          ${alertHtml}
        </div>
        <label class="checkbox-label">
          <input type="checkbox" data-doc-id="${escapeText(doc.canonicalId)}" ${userDoc.ready ? 'checked' : ''} />
          <span>Ready</span>
        </label>
      `;

      const checkbox = row.querySelector('input[type="checkbox"]');
      checkbox.addEventListener('change', async (e) => {
        await fetch('/api/documents/toggle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            studentId: STUDENT_ID,
            docId: doc.canonicalId,
            ready: e.target.checked,
            issuedDate: userDoc.issuedDate || new Date().toISOString().slice(0, 10)
          })
        });
        await refreshMatch();
      });

      container.appendChild(row);
    });
  }

  function renderScholarshipFeed(eligible, applications) {
    const grid = $('scholarshipFeed');
    grid.innerHTML = '';

    if (!eligible || eligible.length === 0) {
      grid.innerHTML = `<div class="card"><p class="muted-sm">No qualifying scholarships match the current filter. Adjust income, GPA, or category filter.</p></div>`;
      return;
    }

    eligible.forEach((sch) => {
      const currentStage = (applications && applications[sch.id]) || null;
      const urgencyClass =
        sch.countdown.urgency === 'CRITICAL'
          ? 'badge-crimson'
          : sch.countdown.urgency === 'URGENT'
          ? 'badge-amber'
          : 'badge-soft';

      const docBadgeClass =
        sch.docReadiness.expiringSoonCount > 0
          ? 'badge-amber'
          : sch.docReadiness.readinessPct === 100
          ? 'badge-emerald'
          : 'badge-soft';

      const card = document.createElement('article');
      card.className = 'sch-card';
      card.innerHTML = `
        <div>
          <div class="sch-top">
            <span class="badge badge-soft">${escapeText(sch.category)}</span>
            <div class="sch-amount">${formatINR(sch.amount)}</div>
          </div>
          <h3 class="sch-title">${escapeText(sch.name)}</h3>
          <div class="sch-provider">${escapeText(sch.provider)}</div>
          <p class="sch-summary">${escapeText(sch.localizedSummary)}</p>
        </div>

        <div>
          <div class="sch-meta-row">
            <span class="countdown-tag ${urgencyClass === 'badge-crimson' ? 'accent-crimson' : ''}">
              ⏱ ${escapeText(sch.countdown.label)}
            </span>
            <span class="badge ${docBadgeClass}">
              Docs ${sch.docReadiness.readyCount}/${sch.docReadiness.totalCount} (${sch.docReadiness.readinessPct}%)
            </span>
            <span class="badge badge-emerald">${sch.matchScore}% Match</span>
          </div>

          <div class="sch-actions" style="margin-top:0.75rem;">
            <button type="button" class="btn btn-primary btn-sm inspect-btn">Inspect & Checklist</button>
            <button type="button" class="btn btn-secondary btn-sm bookmark-btn">
              ${currentStage ? escapeText(currentStage) : 'Bookmark'}
            </button>
          </div>
        </div>
      `;

      card.querySelector('.inspect-btn').addEventListener('click', () => openInspector(sch));
      card.querySelector('.bookmark-btn').addEventListener('click', async () => {
        const nextStage = currentStage ? 'Applied' : 'Bookmarked';
        await fetch('/api/applications/stage', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            studentId: STUDENT_ID,
            scholarshipId: sch.id,
            stage: nextStage
          })
        });
        await refreshMatch();
      });

      grid.appendChild(card);
    });
  }

  function renderNearMiss(nearMiss) {
    const list = $('nearMissList');
    list.innerHTML = '';
    if (!nearMiss || nearMiss.length === 0) {
      list.innerHTML = '<p class="muted-sm">No near-miss schemes at ≥60% threshold for this profile.</p>';
      return;
    }

    nearMiss.forEach((item) => {
      const div = document.createElement('div');
      div.className = 'near-miss-item';
      div.innerHTML = `
        <div style="display:flex;justify-content:space-between;gap:0.5rem;">
          <strong>${escapeText(item.name)}</strong>
          <span class="badge badge-amber">${item.matchScore}%</span>
        </div>
        <div class="muted-sm" style="margin-top:0.3rem;">Award: ${formatINR(item.amount)}</div>
        <div style="font-size:0.78rem;color:var(--accent-crimson);margin-top:0.25rem;">
          Gap: ${escapeText(item.failedReasons.join(' • ') || 'Criteria mismatch')}
        </div>
      `;
      list.appendChild(div);
    });
  }

  function renderPipeline(eligible, applications) {
    const grid = $('pipelineGrid');
    grid.innerHTML = '';
    const entries = Object.entries(applications || {});
    $('pipelineCountBadge').textContent = `${entries.length} Tracked`;

    if (entries.length === 0) {
      grid.innerHTML = '<p class="muted-sm">Bookmark or apply to scholarships above to track stages here.</p>';
      return;
    }

    const catalogMap = new Map((eligible || []).map((s) => [s.id, s]));

    entries.forEach(([schId, stage]) => {
      const sch = catalogMap.get(schId);
      const title = sch ? sch.name : `Scheme ${schId}`;
      const amountText = sch ? formatINR(sch.amount) : '';

      const item = document.createElement('div');
      item.className = 'pipeline-item';
      item.innerHTML = `
        <div style="display:flex;justify-content:space-between;gap:0.4rem;">
          <strong style="font-size:0.86rem;">${escapeText(title)}</strong>
          <span class="accent-emerald" style="font-weight:700;font-size:0.84rem;">${escapeText(amountText)}</span>
        </div>
        <select aria-label="Application stage for ${escapeText(title)}">
          <option value="Bookmarked" ${stage === 'Bookmarked' ? 'selected' : ''}>Bookmarked</option>
          <option value="Applied" ${stage === 'Applied' ? 'selected' : ''}>Applied</option>
          <option value="Under Review" ${stage === 'Under Review' ? 'selected' : ''}>Under Review</option>
          <option value="Awarded" ${stage === 'Awarded' ? 'selected' : ''}>Awarded</option>
        </select>
      `;

      item.querySelector('select').addEventListener('change', async (e) => {
        await fetch('/api/applications/stage', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            studentId: STUDENT_ID,
            scholarshipId: schId,
            stage: e.target.value
          })
        });
        await refreshMatch();
      });

      grid.appendChild(item);
    });
  }

  function openInspector(sch) {
    $('modalCategory').textContent = sch.category;
    $('modalTitle').textContent = sch.name;
    $('modalProvider').textContent = `${sch.provider} • ${sch.frequency}`;
    $('modalPortalLink').href = sch.portalUrl || 'https://scholarships.gov.in/';

    const traceItems = (sch.traces || [])
      .map(
        (t) =>
          `<li>${t.passed ? '✅' : '❌'} <strong>${escapeText(t.label)}</strong> — ${escapeText(t.reason)}</li>`
      )
      .join('');

    const docItems = (sch.docReadiness?.checklist || [])
      .map((d) => {
        const statusLabel = d.ready
          ? d.expiryStatus === 'EXPIRING_SOON'
            ? `Ready (Expiring in ${d.daysUntilExpiry}d)`
            : d.expiryStatus === 'EXPIRED'
            ? 'Ready (Expired — Renew)'
            : 'Ready'
          : 'Missing';
        return `<li>${d.ready ? '☑️' : '⬜'} <strong>${escapeText(d.canonicalName)}</strong> — <em>${escapeText(statusLabel)}</em></li>`;
      })
      .join('');

    $('modalBody').innerHTML = `
      <div><strong>Award Amount:</strong> ${formatINR(sch.amount)} | <strong>Deadline:</strong> ${escapeText(sch.countdown.label)}</div>
      <div><strong>Summary:</strong> ${escapeText(sch.localizedSummary)}</div>
      <div><strong>Renewal Conditions:</strong> ${escapeText(sch.renewalRules)}</div>
      <div><strong>AST Eligibility Trace:</strong><ul style="margin:0.35rem 0;padding-left:1.2rem;">${traceItems}</ul></div>
      <div><strong>Document Readiness Checklist (${sch.docReadiness.readyCount}/${sch.docReadiness.totalCount}):</strong><ul style="margin:0.35rem 0;padding-left:1.2rem;">${docItems}</ul></div>
    `;

    $('inspectorModal').showModal();
  }

  // Event listeners
  $('eligibilityForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    await refreshMatch();
  });

  $('langSelect').addEventListener('change', refreshMatch);

  $('categoryPills').addEventListener('click', async (e) => {
    const btn = e.target.closest('.pill');
    if (!btn) return;
    document.querySelectorAll('#categoryPills .pill').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    state.category = btn.dataset.category || 'All';
    await refreshMatch();
  });

  $('searchInput').addEventListener('input', async (e) => {
    state.search = e.target.value;
    await refreshMatch();
  });

  $('closeModalBtn').addEventListener('click', () => $('inspectorModal').close());
  $('closeWaBtn').addEventListener('click', () => $('whatsappModal').close());

  $('whatsappAlertBtn').addEventListener('click', async () => {
    const res = await fetch('/api/alerts/whatsapp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId: STUDENT_ID })
    });
    const data = await res.json();
    $('waMeta').textContent = `To: ${data.phone} • Schedule: ${data.scheduledFor}`;
    $('waMessageBox').textContent = data.message;
    $('whatsappModal').showModal();
  });

  $('copyWaBtn').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText($('waMessageBox').textContent);
      $('copyWaBtn').textContent = 'Copied!';
      setTimeout(() => {
        $('copyWaBtn').textContent = 'Copy Alert Text';
      }, 1500);
    } catch {
      // Ignore clipboard errors in non-secure contexts
    }
  });

  // Initial load
  refreshMatch();
})();
