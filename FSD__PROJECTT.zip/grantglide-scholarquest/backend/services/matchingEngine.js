/**
 * GrantGlide AST Rule Evaluator, Explainability Engine, Conflict Resolver & Aid Optimizer
 */

function evaluateLeafPredicate(pred, profile) {
  const actual = profile[pred.field];
  const target = pred.value;

  switch (pred.op) {
    case 'eq': {
      const passed = actual === target;
      return {
        passed,
        label: pred.label || `${pred.field} == ${target}`,
        actual,
        expected: target,
        reason: passed
          ? `Met (${pred.field}: ${actual})`
          : `Requires ${pred.field} = ${target}, got ${actual}`
      };
    }
    case 'lte': {
      const numActual = Number(actual);
      const numTarget = Number(target);
      const passed = Number.isFinite(numActual) && numActual <= numTarget;
      return {
        passed,
        label: pred.label || `${pred.field} ≤ ${numTarget}`,
        actual: numActual,
        expected: numTarget,
        reason: passed
          ? `Within ceiling (₹${numActual.toLocaleString('en-IN')} ≤ ₹${numTarget.toLocaleString('en-IN')})`
          : `Exceeds ceiling by ₹${Math.max(0, numActual - numTarget).toLocaleString('en-IN')} (max ₹${numTarget.toLocaleString('en-IN')})`
      };
    }
    case 'gte': {
      const numActual = Number(actual);
      const numTarget = Number(target);
      const passed = Number.isFinite(numActual) && numActual >= numTarget;
      return {
        passed,
        label: pred.label || `${pred.field} ≥ ${numTarget}`,
        actual: numActual,
        expected: numTarget,
        reason: passed
          ? `Meets threshold (${numActual} ≥ ${numTarget})`
          : `Short by ${(numTarget - numActual).toFixed(2)} (requires ≥ ${numTarget})`
      };
    }
    case 'in': {
      const arr = Array.isArray(target) ? target : [];
      const passed = arr.includes(actual);
      return {
        passed,
        label: pred.label || `${pred.field} in [${arr.join(', ')}]`,
        actual,
        expected: arr,
        reason: passed
          ? `Matches eligible set (${actual})`
          : `${actual} not in eligible set [${arr.join(', ')}]`
      };
    }
    default:
      return { passed: false, label: 'Unknown operator', reason: 'Unsupported rule operator' };
  }
}

/**
 * Recursively evaluates a JSON AST predicate tree ({ and: [...] } | { or: [...] } | leaf)
 * Returns { passed, scoreRatio, traces[], failedReasons[] }
 */
function evaluateRuleTree(node, profile) {
  if (!node || typeof node !== 'object') {
    return { passed: true, scoreRatio: 1, traces: [], failedReasons: [] };
  }

  if (Array.isArray(node.and)) {
    const childResults = node.and.map((child) => evaluateRuleTree(child, profile));
    const passed = childResults.every((r) => r.passed);
    const traces = childResults.flatMap((r) => r.traces);
    const failedReasons = childResults.flatMap((r) => r.failedReasons);
    const passedCount = childResults.filter((r) => r.passed).length;
    const scoreRatio = childResults.length > 0 ? passedCount / childResults.length : 1;
    return { passed, scoreRatio, traces, failedReasons };
  }

  if (Array.isArray(node.or)) {
    const childResults = node.or.map((child) => evaluateRuleTree(child, profile));
    const passed = childResults.some((r) => r.passed);
    const traces = childResults.flatMap((r) => r.traces);
    const bestRatio = childResults.reduce((max, r) => Math.max(max, r.scoreRatio), 0);
    const failedReasons = passed
      ? []
      : childResults.map((r) => r.failedReasons.join(' OR ')).filter(Boolean);
    return { passed, scoreRatio: passed ? 1 : bestRatio, traces, failedReasons };
  }

  const leaf = evaluateLeafPredicate(node, profile);
  return {
    passed: leaf.passed,
    scoreRatio: leaf.passed ? 1 : 0,
    traces: [leaf],
    failedReasons: leaf.passed ? [] : [leaf.reason]
  };
}

function computeCountdown(deadlineIso, nowMs = Date.now()) {
  const targetMs = new Date(deadlineIso).getTime();
  const diffMs = Math.max(0, targetMs - nowMs);
  const totalHours = Math.floor(diffMs / (1000 * 60 * 60));
  const days = Math.floor(totalHours / 24);
  const hours = totalHours % 24;
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

  let urgency = 'NORMAL';
  if (days <= 7) urgency = 'CRITICAL';
  else if (days <= 14) urgency = 'URGENT';
  else if (days <= 25) urgency = 'MODERATE';

  return {
    deadlineIso,
    daysRemaining: days,
    hoursRemaining: hours,
    minutesRemaining: minutes,
    urgency,
    label: `${days}d ${hours}h left`
  };
}

function evaluateDocumentReadiness(requiredDocs, docCatalog, studentDocs, nowMs = Date.now()) {
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
  let readyCount = 0;
  let expiringSoonCount = 0;

  const checklist = requiredDocs.map((docId) => {
    const meta = docCatalog[docId] || {
      canonicalId: docId,
      canonicalName: docId,
      validityDays: 365,
      aliases: { Default: docId }
    };
    const userDoc = studentDocs[docId] || { ready: false, issuedDate: null };
    let expiryStatus = 'MISSING';
    let daysUntilExpiry = null;

    if (userDoc.ready) {
      readyCount += 1;
      expiryStatus = 'VALID';
      if (userDoc.issuedDate) {
        const issuedMs = new Date(userDoc.issuedDate).getTime();
        const expiresMs = issuedMs + (meta.validityDays || 365) * 24 * 60 * 60 * 1000;
        daysUntilExpiry = Math.ceil((expiresMs - nowMs) / (1000 * 60 * 60 * 24));
        if (daysUntilExpiry <= 0) {
          expiryStatus = 'EXPIRED';
          expiringSoonCount += 1;
        } else if (expiresMs - nowMs <= thirtyDaysMs) {
          expiryStatus = 'EXPIRING_SOON';
          expiringSoonCount += 1;
        }
      }
    }

    return {
      docId,
      canonicalName: meta.canonicalName,
      aliases: meta.aliases,
      ready: Boolean(userDoc.ready),
      issuedDate: userDoc.issuedDate || null,
      expiryStatus,
      daysUntilExpiry
    };
  });

  const total = requiredDocs.length;
  const readinessPct = total > 0 ? Math.round((readyCount / total) * 100) : 100;

  return {
    readyCount,
    totalCount: total,
    readinessPct,
    expiringSoonCount,
    checklist
  };
}

/**
 * Conflict Graph Solver: Detects mutual exclusions among selected/matched scholarships
 * and computes an optimal non-conflicting scholarship stack to cover tuition deficit.
 */
function detectConflictsAndOptimizeAid(eligibleScholarships, selectedIds, tuitionFee) {
  const byId = new Map(eligibleScholarships.map((s) => [s.id, s]));
  const selectedSet = new Set(selectedIds.filter((id) => byId.has(id)));
  const conflicts = [];

  const selectedArr = Array.from(selectedSet);
  for (let i = 0; i < selectedArr.length; i++) {
    for (let j = i + 1; j < selectedArr.length; j++) {
      const a = byId.get(selectedArr[i]);
      const b = byId.get(selectedArr[j]);
      const explicitConflict =
        (Array.isArray(a.conflictsWith) && a.conflictsWith.includes(b.id)) ||
        (Array.isArray(b.conflictsWith) && b.conflictsWith.includes(a.id));
      const sameGroup = a.conflictGroup && b.conflictGroup && a.conflictGroup === b.conflictGroup;

      if (explicitConflict || sameGroup) {
        conflicts.push({
          schemeA: { id: a.id, name: a.name, amount: a.amount },
          schemeB: { id: b.id, name: b.name, amount: b.amount },
          reason: a.conflictReason || b.conflictReason || 'Mutually exclusive scholarship schemes.'
        });
      }
    }
  }

  // Treat exclusions as undirected, even when only one scheme lists the other.
  const conflictsById = new Map(eligibleScholarships.map((sch) => [sch.id, new Set()]));
  for (let i = 0; i < eligibleScholarships.length; i++) {
    for (let j = i + 1; j < eligibleScholarships.length; j++) {
      const a = eligibleScholarships[i];
      const b = eligibleScholarships[j];
      const explicitConflict =
        (Array.isArray(a.conflictsWith) && a.conflictsWith.includes(b.id)) ||
        (Array.isArray(b.conflictsWith) && b.conflictsWith.includes(a.id));
      const sameGroup = a.conflictGroup && b.conflictGroup && a.conflictGroup === b.conflictGroup;

      if (explicitConflict || sameGroup) {
        conflictsById.get(a.id).add(b.id);
        conflictsById.get(b.id).add(a.id);
      }
    }
  }

  // Greedy conflict-free aid maximizer sorted by award amount descending
  const sortedByValue = [...eligibleScholarships].sort((x, y) => y.amount - x.amount);
  const optimalStack = [];
  const includedIds = new Set();

  for (const sch of sortedByValue) {
    const conflictingIds = conflictsById.get(sch.id) || new Set();
    if ([...conflictingIds].some((id) => includedIds.has(id))) continue;

    optimalStack.push({
      id: sch.id,
      name: sch.name,
      amount: sch.amount,
      category: sch.category
    });
    includedIds.add(sch.id);
  }

  const optimalTotalAid = optimalStack.reduce((sum, s) => sum + s.amount, 0);
  const selectedTotalAid = selectedArr.reduce((sum, id) => sum + (byId.get(id)?.amount || 0), 0);
  const remainingDeficitAfterOptimal = Math.max(0, Number(tuitionFee || 0) - optimalTotalAid);
  const coveragePct =
    Number(tuitionFee) > 0 ? Math.min(100, Math.round((optimalTotalAid / Number(tuitionFee)) * 100)) : 100;

  return {
    tuitionFee: Number(tuitionFee || 0),
    selectedTotalAid,
    optimalTotalAid,
    remainingDeficitAfterOptimal,
    coveragePct,
    conflicts,
    optimalStack
  };
}

function matchScholarshipsForProfile(scholarships, docCatalog, studentState, options = {}) {
  const { category = 'All', search = '', lang = 'en', selectedIds = [] } = options;
  const nowMs = Date.now();
  const queryLower = String(search || '').trim().toLowerCase();

  const evaluated = scholarships.map((sch) => {
    const astResult = evaluateRuleTree(sch.ruleTree, studentState.profile);
    const totalLeaves = Math.max(1, astResult.traces.length);
    const passedLeaves = astResult.traces.filter((t) => t.passed).length;
    const matchScore = Math.round((passedLeaves / totalLeaves) * 100);

    const countdown = computeCountdown(sch.deadline, nowMs);
    const docReadiness = evaluateDocumentReadiness(
      sch.requiredDocs || [],
      docCatalog,
      studentState.documents || {},
      nowMs
    );

    const localizedSummary =
      lang !== 'en' && sch.translations && sch.translations[lang]
        ? sch.translations[lang]
        : `${sch.provider} — ${sch.frequency}. Renewal: ${sch.renewalRules}`;

    return {
      ...sch,
      eligible: astResult.passed,
      matchScore,
      passedLeaves,
      totalLeaves,
      traces: astResult.traces,
      failedReasons: astResult.failedReasons,
      countdown,
      docReadiness,
      localizedSummary
    };
  });

  const eligibleList = evaluated.filter((item) => item.eligible);
  const nearMissList = evaluated
    .filter((item) => !item.eligible && item.matchScore >= 60)
    .sort((a, b) => b.matchScore - a.matchScore);

  const filteredEligible = eligibleList.filter((item) => {
    const matchesCat =
      !category ||
      category === 'All' ||
      item.category === category ||
      (Array.isArray(item.tags) && item.tags.includes(category));
    const matchesSearch =
      !queryLower ||
      item.name.toLowerCase().includes(queryLower) ||
      item.provider.toLowerCase().includes(queryLower) ||
      item.category.toLowerCase().includes(queryLower);
    return matchesCat && matchesSearch;
  });

  filteredEligible.sort((a, b) => {
    if (b.matchScore !== a.matchScore) return b.matchScore - a.matchScore;
    return b.amount - a.amount;
  });

  const activeSelection = selectedIds.length > 0 ? selectedIds : filteredEligible.slice(0, 4).map((x) => x.id);
  const aidPlan = detectConflictsAndOptimizeAid(
    eligibleList,
    activeSelection,
    studentState.profile.tuitionFee
  );

  return {
    totalCatalogCount: scholarships.length,
    eligibleCount: eligibleList.length,
    filteredCount: filteredEligible.length,
    nearMissCount: nearMissList.length,
    eligible: filteredEligible,
    allEligibleIds: eligibleList.map((e) => e.id),
    nearMiss: nearMissList.slice(0, 6),
    aidPlan
  };
}

module.exports = {
  evaluateRuleTree,
  computeCountdown,
  evaluateDocumentReadiness,
  detectConflictsAndOptimizeAid,
  matchScholarshipsForProfile
};
