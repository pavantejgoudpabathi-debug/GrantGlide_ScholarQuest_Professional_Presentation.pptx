const express = require('express');
const fs = require('fs');
const path = require('path');
const {
  studentProfileSchema,
  applicationStageSchema,
  docToggleSchema,
  strictMutationLimiter,
  signPayload,
  safeUrlCheck
} = require('../middleware/security');
const { matchScholarshipsForProfile, computeCountdown } = require('../services/matchingEngine');

const router = express.Router();

const DATA_DIR = path.join(__dirname, '..', 'data');
const scholarships = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'scholarships.json'), 'utf8'));
const docCatalog = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'doc_catalog.json'), 'utf8'));

// In-memory store with HMAC integrity stamps (persisted to JSON on disk safely)
const STORE_PATH = path.join(DATA_DIR, 'student_store.json');

function defaultStudentState(studentId = 'demo-student-01') {
  return {
    studentId,
    profile: {
      name: 'Ananya Rao',
      caste: 'BC',
      annualIncome: 150000,
      state: 'Telangana',
      gender: 'Female',
      degree: 'B.Tech / Engineering',
      gpa: 8.5,
      singleGirlChild: false,
      disability: false,
      tuitionFee: 140000,
      language: 'en',
      phone: '+91 98480 22110'
    },
    documents: {
      PROOF_OF_INCOME: { ready: true, issuedDate: '2025-12-08' }, // Expiring soon (~18 days left as of Nov 20, 2026)
      PROOF_OF_CASTE: { ready: true, issuedDate: '2024-06-15' },
      PROOF_OF_DOMICILE: { ready: true, issuedDate: '2023-07-01' },
      ACADEMIC_MARKSHEETS: { ready: false, issuedDate: null },
      BONAFIDE_CERTIFICATE: { ready: false, issuedDate: null },
      DISABILITY_CERTIFICATE: { ready: false, issuedDate: null }
    },
    applications: {
      'sch-001': 'Bookmarked',
      'sch-003': 'Applied'
    }
  };
}

function loadStore() {
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = JSON.parse(fs.readFileSync(STORE_PATH, 'utf8'));
      if (raw && typeof raw === 'object' && raw.students) {
        return raw;
      }
    }
  } catch {
    // Fallback to clean state
  }
  const initial = {
    students: {
      'demo-student-01': defaultStudentState('demo-student-01')
    }
  };
  saveStore(initial);
  return initial;
}

function saveStore(store) {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf8');
  } catch {
    // Ignore read-only filesystem errors in ephemeral containers
  }
}

const store = loadStore();

function getOrCreateStudent(studentId = 'demo-student-01') {
  const safeId = /^[a-zA-Z0-9_-]{3,40}$/.test(studentId) ? studentId : 'demo-student-01';
  if (!store.students[safeId]) {
    store.students[safeId] = defaultStudentState(safeId);
    saveStore(store);
  }
  return store.students[safeId];
}

// GET /api/health
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'GrantGlide: ScholarQuest API',
    version: '2.0.0',
    schemesLoaded: scholarships.length,
    securityWalls: [
      'Helmet Strict CSP & HSTS',
      'Multi-Tier Rate Limiting',
      'Prototype Pollution & Control-Char Sanitizer',
      'Zod Strict Schema Validation',
      'HMAC-SHA256 Eligibility & Audit Attestation'
    ],
    timestamp: new Date().toISOString()
  });
});

// GET /api/scholarships (catalog overview with safe portal URLs)
router.get('/scholarships', (req, res) => {
  const category = String(req.query.category || 'All');
  const search = String(req.query.search || '').toLowerCase().trim();
  const list = scholarships
    .filter((s) => {
      const catMatch =
        category === 'All' || s.category === category || (Array.isArray(s.tags) && s.tags.includes(category));
      const textMatch =
        !search || s.name.toLowerCase().includes(search) || s.provider.toLowerCase().includes(search);
      return catMatch && textMatch;
    })
    .map((s) => ({
      id: s.id,
      name: s.name,
      provider: s.provider,
      category: s.category,
      tags: s.tags,
      amount: s.amount,
      frequency: s.frequency,
      deadline: s.deadline,
      portalUrl: safeUrlCheck(s.portalUrl),
      countdown: computeCountdown(s.deadline)
    }));

  res.json({ count: list.length, scholarships: list });
});

// GET /api/student/:studentId
router.get('/student/:studentId', (req, res) => {
  const student = getOrCreateStudent(req.params.studentId);
  res.json({
    student,
    docCatalog,
    signature: signPayload({ studentId: student.studentId, profile: student.profile })
  });
});

// POST /api/match — Evaluate AST eligibility, near-miss, conflicts, aid plan & sign attestation
router.post('/match', strictMutationLimiter, (req, res) => {
  const parsed = studentProfileSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: 'Invalid student profile parameters',
      details: parsed.error.flatten()
    });
  }

  const data = parsed.data;
  const studentId = data.studentId || 'demo-student-01';
  const student = getOrCreateStudent(studentId);

  student.profile = {
    name: data.name,
    caste: data.caste,
    annualIncome: data.annualIncome,
    state: data.state,
    gender: data.gender,
    degree: data.degree,
    gpa: data.gpa,
    singleGirlChild: Boolean(data.singleGirlChild),
    disability: Boolean(data.disability),
    tuitionFee: data.tuitionFee ?? student.profile.tuitionFee ?? 140000,
    language: data.language || 'en',
    phone: data.phone || student.profile.phone || '+91 98480 22110'
  };
  saveStore(store);

  const selectedIds = Array.isArray(req.body.selectedIds)
    ? req.body.selectedIds.filter((id) => typeof id === 'string').slice(0, 32)
    : [];

  const matchResult = matchScholarshipsForProfile(scholarships, docCatalog, student, {
    category: req.body.category || 'All',
    search: req.body.search || '',
    lang: student.profile.language,
    selectedIds
  });

  const attestationPayload = {
    studentId,
    eligibleIds: matchResult.allEligibleIds,
    optimalTotalAid: matchResult.aidPlan.optimalTotalAid
  };

  res.json({
    studentId,
    profile: student.profile,
    documents: student.documents,
    applications: student.applications,
    docCatalog,
    ...matchResult,
    attestation: {
      algorithm: 'HMAC-SHA256',
      signature: signPayload(attestationPayload)
    }
  });
});

// POST /api/documents/toggle
router.post('/documents/toggle', strictMutationLimiter, (req, res) => {
  const parsed = docToggleSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid document update payload', details: parsed.error.flatten() });
  }

  const { studentId, docId, ready, issuedDate } = parsed.data;
  const student = getOrCreateStudent(studentId);
  const defaultDate = ready
    ? issuedDate || new Date().toISOString().slice(0, 10)
    : null;

  student.documents[docId] = {
    ready,
    issuedDate: defaultDate
  };
  saveStore(store);

  res.json({
    studentId,
    documents: student.documents,
    signature: signPayload({ studentId, documents: student.documents })
  });
});

// POST /api/applications/stage
router.post('/applications/stage', strictMutationLimiter, (req, res) => {
  const parsed = applicationStageSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid application stage payload', details: parsed.error.flatten() });
  }

  const { studentId, scholarshipId, stage } = parsed.data;
  const exists = scholarships.some((s) => s.id === scholarshipId);
  if (!exists) {
    return res.status(404).json({ error: 'Scholarship scheme not found' });
  }

  const student = getOrCreateStudent(studentId);
  student.applications[scholarshipId] = stage;
  saveStore(store);

  res.json({
    studentId,
    applications: student.applications,
    signature: signPayload({ studentId, applications: student.applications })
  });
});

// POST /api/alerts/whatsapp — Generates structured WhatsApp deadline & expiry summary
router.post('/alerts/whatsapp', (req, res) => {
  const studentId = typeof req.body?.studentId === 'string' ? req.body.studentId : 'demo-student-01';
  const student = getOrCreateStudent(studentId);
  const matchResult = matchScholarshipsForProfile(scholarships, docCatalog, student, {
    lang: student.profile.language || 'en'
  });

  const topUrgent = matchResult.eligible.slice(0, 4);
  const lines = [
    `*GrantGlide ScholarQuest Alert* for *${student.profile.name}*`,
    `Eligible Schemes: *${matchResult.eligibleCount}* | Optimal Aid: *₹${matchResult.aidPlan.optimalTotalAid.toLocaleString('en-IN')}*`,
    ''
  ];

  topUrgent.forEach((sch, idx) => {
    lines.push(
      `${idx + 1}. *${sch.name}* — ₹${sch.amount.toLocaleString('en-IN')} (${sch.countdown.label}) | Docs: ${sch.docReadiness.readyCount}/${sch.docReadiness.totalCount}`
    );
  });

  if (matchResult.aidPlan.conflicts.length > 0) {
    lines.push('', `⚠️ *Policy Conflict Notice:* ${matchResult.aidPlan.conflicts.length} overlapping scheme pair(s) detected.`);
  }

  const message = lines.join('\n');
  res.json({
    phone: student.profile.phone || '+91 98480 22110',
    scheduledFor: 'Daily 08:00 AM IST & 72h Before Deadline',
    message
  });
});

module.exports = router;
