const express = require('express');
const cors = require('cors');
const path = require('path');
const {
  createHelmetMiddleware,
  apiLimiter,
  sanitizeInputMiddleware
} = require('./middleware/security');
const apiRoutes = require('./routes/api');

function createApp() {
  const app = express();

  app.disable('x-powered-by');

  app.use(createHelmetMiddleware());
  app.use(
    cors({
      origin: (origin, cb) => {
        if (!origin || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
          return cb(null, true);
        }
        return cb(new Error('CORS policy blocked origin'), false);
      },
      methods: ['GET', 'POST'],
      allowedHeaders: ['Content-Type']
    })
  );
  app.use('/api', apiLimiter);
  app.use(express.json({ limit: '64kb' }));
  app.use(sanitizeInputMiddleware);

  app.use(express.static(path.join(__dirname, '..', 'frontend')));
  app.use('/api', apiRoutes);

  app.use((err, req, res, next) => {
    const status = err.status || 500;
    res.status(status).json({
      error: status === 400 ? 'Bad Request' : 'Internal Server Error',
      message: process.env.NODE_ENV === 'production' ? 'Request could not be processed.' : err.message
    });
  });

  return app;
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createApp().listen(port, () => {
    console.log(`GrantGlide: ScholarQuest server running on http://localhost:${port}`);
  });
}

module.exports = { createApp };
