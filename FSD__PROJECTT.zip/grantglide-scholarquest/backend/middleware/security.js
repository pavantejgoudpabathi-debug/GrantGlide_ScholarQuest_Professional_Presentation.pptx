const crypto = require('crypto');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { z } = require('zod');

/**
 * Security Wall 1: Strict Helmet CSP & Transport Hardening
 */
function createHelmetMiddleware() {
  return helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests: []
      }
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
  });
}

/**
 * Security Wall 2: Multi-Tier Rate Limiting (API & Write/Mutation protection)
 */
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 180,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests from this IP. Please slow down and try again shortly.' }
});

const strictMutationLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Rate limit exceeded for profile/application mutations.' }
});

/**
 * Security Wall 3: Prototype Pollution Guard & Deep String Sanitizer
 */
const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function sanitizeValue(val, depth = 0) {
  if (depth > 12) return null;
  if (typeof val === 'string') {
    // Strip control chars & null bytes, trim excess whitespace
    return val.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '').trim();
  }
  if (typeof val === 'number') {
    return Number.isFinite(val) ? val : 0;
  }
  if (typeof val === 'boolean' || val === null || val === undefined) {
    return val;
  }
  if (Array.isArray(val)) {
    return val.slice(0, 100).map((item) => sanitizeValue(item, depth + 1));
  }
  if (typeof val === 'object') {
    const clean = {};
    for (const [k, v] of Object.entries(val)) {
      if (DANGEROUS_KEYS.has(k)) continue;
      const safeKey = String(k).replace(/[^a-zA-Z0-9_\-]/g, '').slice(0, 64);
      if (!safeKey) continue;
      clean[safeKey] = sanitizeValue(v, depth + 1);
    }
    return clean;
  }
  return null;
}

function sanitizeInputMiddleware(req, res, next) {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeValue(req.body);
  }
  if (req.query && typeof req.query === 'object') {
    req.query = sanitizeValue(req.query);
  }
  next();
}

/**
 * Security Wall 4: Strict Zod Schema Validation for Student Profile & Mutations
 */
const ALLOWED_CASTES = ['General', 'EWS', 'BC', 'OBC', 'SC', 'ST'];
const ALLOWED_GENDERS = ['Female', 'Male', 'Non-Binary'];
const ALLOWED_DEGREES = [
  'B.Tech / Engineering',
  'B.Sc / B.Com / BA',
  'Diploma',
  'B.Arch',
  'MBBS / Medical'
];
const ALLOWED_STATES = [
  'Telangana',
  'Andhra Pradesh',
  'Maharashtra',
  'Karnataka',
  'Tamil Nadu',
  'Delhi',
  'Uttar Pradesh',
  'West Bengal',
  'Gujarat',
  'Rajasthan',
  'Other'
];

const studentProfileSchema = z.object({
  studentId: z
    .string()
    .regex(/^[a-zA-Z0-9_-]{3,40}$/)
    .optional(),
  name: z.string().min(1).max(80).default('Ananya Rao'),
  caste: z.enum(ALLOWED_CASTES),
  annualIncome: z.coerce.number().finite().min(0).max(10000000),
  state: z.string().min(2).max(50).default('Telangana'),
  gender: z.enum(ALLOWED_GENDERS),
  degree: z.string().min(2).max(60).default('B.Tech / Engineering'),
  gpa: z.coerce.number().finite().min(0).max(10),
  singleGirlChild: z.boolean().optional().default(false),
  disability: z.boolean().optional().default(false),
  tuitionFee: z.coerce.number().finite().min(0).max(5000000).optional().default(120000),
  language: z.enum(['en', 'hi', 'te', 'ta']).optional().default('en'),
  phone: z.string().regex(/^[+0-9\s-]{0,20}$/).optional().default('+91 98480 22110')
});

const applicationStageSchema = z.object({
  studentId: z.string().regex(/^[a-zA-Z0-9_-]{3,40}$/).default('demo-student-01'),
  scholarshipId: z.string().regex(/^sch-[0-9]{3}$/),
  stage: z.enum(['Bookmarked', 'Applied', 'Under Review', 'Awarded'])
});

const docToggleSchema = z.object({
  studentId: z.string().regex(/^[a-zA-Z0-9_-]{3,40}$/).default('demo-student-01'),
  docId: z.enum([
    'PROOF_OF_INCOME',
    'PROOF_OF_CASTE',
    'PROOF_OF_DOMICILE',
    'ACADEMIC_MARKSHEETS',
    'BONAFIDE_CERTIFICATE',
    'DISABILITY_CERTIFICATE'
  ]),
  ready: z.boolean(),
  issuedDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .refine((value) => {
      const timestamp = Date.parse(`${value}T00:00:00.000Z`);
      return Number.isFinite(timestamp) && new Date(timestamp).toISOString().slice(0, 10) === value;
    }, 'Expected a valid calendar date')
    .optional()
});

/**
 * Security Wall 5: Cryptographic Integrity & Audit Ledger (HMAC-SHA256)
 */
const configuredSigningSecret = process.env.GRANTGLIDE_HMAC_SECRET;
if (process.env.NODE_ENV === 'production' && (!configuredSigningSecret || configuredSigningSecret.length < 32)) {
  throw new Error('GRANTGLIDE_HMAC_SECRET must contain at least 32 characters in production.');
}
const SIGNING_SECRET = configuredSigningSecret || crypto.randomBytes(32).toString('hex');

function signPayload(payloadObj) {
  const canonical = JSON.stringify(payloadObj);
  return crypto.createHmac('sha256', SIGNING_SECRET).update(canonical).digest('hex');
}

function safeUrlCheck(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' ? parsed.toString() : 'https://scholarships.gov.in/';
  } catch {
    return 'https://scholarships.gov.in/';
  }
}

module.exports = {
  createHelmetMiddleware,
  apiLimiter,
  strictMutationLimiter,
  sanitizeInputMiddleware,
  studentProfileSchema,
  applicationStageSchema,
  docToggleSchema,
  signPayload,
  safeUrlCheck,
  ALLOWED_CASTES,
  ALLOWED_GENDERS,
  ALLOWED_DEGREES,
  ALLOWED_STATES
};
