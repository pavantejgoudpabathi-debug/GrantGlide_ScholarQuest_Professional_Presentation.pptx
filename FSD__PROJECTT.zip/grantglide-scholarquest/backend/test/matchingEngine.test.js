const assert = require('node:assert/strict');
const { test } = require('node:test');
const {
  evaluateRuleTree,
  computeCountdown,
  evaluateDocumentReadiness,
  detectConflictsAndOptimizeAid
} = require('../services/matchingEngine');

test('evaluates nested AND and OR rules with useful traces', () => {
  const result = evaluateRuleTree(
    {
      and: [
        { field: 'gpa', op: 'gte', value: 7 },
        {
          or: [
            { field: 'caste', op: 'in', value: ['SC', 'ST'] },
            { field: 'singleGirlChild', op: 'eq', value: true }
          ]
        }
      ]
    },
    { gpa: 8.2, caste: 'BC', singleGirlChild: true }
  );

  assert.equal(result.passed, true);
  assert.equal(result.traces.length, 3);
  assert.deepEqual(result.failedReasons, []);
});

test('rejects unsupported rule operators', () => {
  const result = evaluateRuleTree(
    { field: 'gpa', op: 'approx', value: 8 },
    { gpa: 8 }
  );

  assert.equal(result.passed, false);
  assert.deepEqual(result.failedReasons, ['Unsupported rule operator']);
});

test('computes a deterministic deadline countdown', () => {
  const now = Date.UTC(2026, 0, 1);
  const deadline = new Date(now + 3 * 24 * 60 * 60 * 1000).toISOString();
  const result = computeCountdown(deadline, now);

  assert.equal(result.daysRemaining, 3);
  assert.equal(result.urgency, 'CRITICAL');
  assert.equal(result.label, '3d 0h left');
});

test('marks missing and soon-to-expire documents correctly', () => {
  const result = evaluateDocumentReadiness(
    ['INCOME', 'MARKSHEET'],
    {
      INCOME: { canonicalName: 'Income certificate', aliases: {}, validityDays: 365 }
    },
    { INCOME: { ready: true, issuedDate: '2026-01-01' } },
    Date.UTC(2026, 11, 20)
  );

  assert.equal(result.readinessPct, 50);
  assert.equal(result.checklist[0].expiryStatus, 'EXPIRING_SOON');
  assert.equal(result.checklist[0].daysUntilExpiry, 12);
  assert.equal(result.checklist[1].expiryStatus, 'MISSING');
});

test('keeps the optimized aid stack free of one-sided conflicts', () => {
  const result = detectConflictsAndOptimizeAid(
    [
      { id: 'A', name: 'A', amount: 100, category: 'Merit', conflictsWith: [] },
      { id: 'B', name: 'B', amount: 90, category: 'State', conflictsWith: ['A'] },
      { id: 'C', name: 'C', amount: 50, category: 'Need', conflictsWith: [] }
    ],
    ['A', 'B', 'unknown', 'A'],
    200
  );

  assert.equal(result.conflicts.length, 1);
  assert.equal(result.selectedTotalAid, 190);
  assert.deepEqual(result.optimalStack.map((scheme) => scheme.id), ['A', 'C']);
  assert.equal(result.optimalTotalAid, 150);
});
