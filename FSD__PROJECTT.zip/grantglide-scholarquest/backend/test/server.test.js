const assert = require('node:assert/strict');
const { once } = require('node:events');
const { test } = require('node:test');
const { createApp } = require('../server');

test('serves the UI and health route and rejects invalid profiles', async (t) => {
  const server = createApp().listen(0);
  await once(server, 'listening');
  t.after(() => new Promise((resolve, reject) => {
    server.close((error) => error ? reject(error) : resolve());
  }));

  const address = server.address();
  const baseUrl = 'http://127.0.0.1:' + address.port;

  const page = await fetch(baseUrl);
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-type'), /text\/html/);
  assert.equal(page.headers.get('x-powered-by'), null);
  const markup = await page.text();
  assert.match(markup, /id="appStatus"[^>]*aria-live="polite"/);
  assert.doesNotMatch(markup, /id="eligibilityForm"[^>]*novalidate/);

  const health = await fetch(baseUrl + '/api/health');
  assert.equal(health.status, 200);
  assert.equal((await health.json()).status, 'ok');

  const invalidProfile = await fetch(baseUrl + '/api/match', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({})
  });
  assert.equal(invalidProfile.status, 400);
});
