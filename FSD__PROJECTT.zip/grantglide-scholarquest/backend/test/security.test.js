const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const { test } = require('node:test');
const {
  studentProfileSchema,
  docToggleSchema,
  safeUrlCheck,
  signPayload
} = require('../middleware/security');

test('accepts a valid profile and applies documented defaults', () => {
  const result = studentProfileSchema.safeParse({
    caste: 'BC',
    annualIncome: '150000',
    gender: 'Female',
    gpa: '8.5'
  });

  assert.equal(result.success, true);
  assert.equal(result.data.name, 'Ananya Rao');
  assert.equal(result.data.tuitionFee, 120000);
});

test('rejects invalid calendar dates for document issue dates', () => {
  const result = docToggleSchema.safeParse({
    docId: 'PROOF_OF_INCOME',
    ready: true,
    issuedDate: '2026-02-31'
  });

  assert.equal(result.success, false);
});

test('accepts a real calendar date for document issue dates', () => {
  const result = docToggleSchema.safeParse({
    docId: 'PROOF_OF_INCOME',
    ready: true,
    issuedDate: '2026-02-28'
  });

  assert.equal(result.success, true);
});

test('falls back to a trusted HTTPS portal for unsafe URLs', () => {
  assert.equal(safeUrlCheck('javascript:alert(1)'), 'https://scholarships.gov.in/');
  assert.equal(safeUrlCheck('https://example.gov.in/apply'), 'https://example.gov.in/apply');
});

test('uses a stable signature for the same payload during one process', () => {
  const payload = { studentId: 'student_001', eligibleIds: ['sch-001'] };
  assert.equal(signPayload(payload), signPayload(payload));
  assert.match(signPayload(payload), /^[a-f0-9]{64}$/);
});

test('requires an explicit signing secret in production', () => {
  const env = { ...process.env, NODE_ENV: 'production' };
  delete env.GRANTGLIDE_HMAC_SECRET;
  const result = spawnSync(process.execPath, ['-e', "require('./middleware/security')"], {
    cwd: path.join(__dirname, '..'),
    env,
    encoding: 'utf8'
  });

  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /GRANTGLIDE_HMAC_SECRET must contain at least 32 characters/);
});
